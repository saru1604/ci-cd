# Build .NET 5 Applications with GitHub Actions

[Blog Post: Build .NET 5 Applications with GitHub Actions](https://www.elliotdenolf.com/posts/build-net-5-applications-with-github-actions/)
