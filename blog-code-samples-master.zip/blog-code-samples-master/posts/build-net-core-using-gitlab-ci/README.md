# Build .NET Core Applications using GitLab CI

[Blog Post: Build .NET Core Applications using GitLab CI](https://www.elliotdenolf.com/posts/build-net-core-applications-using-gitlab-ci/)

## How to Run

This repo is to be committed to GitLab in order to run GitLab CI
