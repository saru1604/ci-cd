# C# Scripting using dotnet-script

[Blog Post: C# Scripting using dotnet-script](https://www.elliotdenolf.com/posts/csharp-scripting-using-dotnet-script/)

## How to Run

Follow post to install dotnet-script pre-requisite then run script with `./main.csx` from command line
