# Cucumber.js with TypeScript

[Blog Post: Cucumber.js with TypeScript](https://www.elliotdenolf.com/posts/cucumberjs-with-typescript/)

## How to Run

### Steps

- `git clone` repo, `cd` into directory
- `npm install`
- Run tests with `npm test`

